Flappy Airplane Game 9/11

A simple Flappy Bird-style game where you control an airplane to avoid building obstacles. The game features day and night cycles, clouds, and sound effects.

Features

Airplane Movement – Click to make the plane fly.

Obstacles – Avoid buildings to stay alive.

Day/Night Cycle – Background switches between day and night every 15 seconds.

Score System – Track your score and highest score.

Pause/Resume – Pause and resume the game anytime.

Sound Effects – Includes flying, jumping, and crash sounds.


How to Play

1. Click anywhere on the screen to make the airplane jump.


2. Avoid hitting buildings or going out of bounds.


3. The game speeds up over time.


4. Try to get the highest score possible!



Game Controls

Project Structure

/flappy-airplane/
│── index.html  # Main game file
│── README.md   # Game instructions
│── /airplane/
│   └── PlaneDrawing.png
│── /building/
│   ├── building.png
│   ├── crash.png
│── /background/
│   ├── night.png
│   ├── Cloud0.png
│   ├── Cloud1.png
│   ├── Cloud2.png
│── /sounds/
│   ├── planeSound1.wav
│   ├── takeOffSound.wav
│   ├── crash.wav

Technologies Used

HTML5 Canvas – For game rendering

JavaScript – Game logic and animations

CSS – Styling elements


To-Do List

[ ] Improve collision detection

[ ] Add more airplane skins

[ ] Implement difficulty levels

[ ] Fix the Day-Night-Cycle

[ ] Fix the tap bug

Credits

Created by Hener, also known as Hena.