const CACHE_NAME = "flappy-airplane-v1";
const ASSETS = [
    "index.html",
    "script.js",
    "style.css",
    "manifest.json",
    "images/airplane.png",
    "images/building.png",
    "images/crash.png",
    "images/icon192.png",
    "images/icon512.png",
    "sounds/planeSound1.wav",
    "sounds/takeOffSound.wav",
    "sounds/crash.wav"
];

// Install Service Worker and Cache Files
self.addEventListener("install", event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(ASSETS);
        })
    );
});

// Fetch Cached Files When Offline
self.addEventListener("fetch", event => {
    event.respondWith(
        caches.match(event.request).then(response => {
            return response || fetch(event.request);
        })
    );
});